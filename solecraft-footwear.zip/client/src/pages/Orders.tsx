import { useState } from "react";
import { Link, useRoute } from "wouter";
import { toast } from "sonner";
import { AccountLayout } from "@/components/AccountLayout";
import { pkr } from "@/components/ProductCard";
import { trpc } from "@/lib/trpc";

export function Orders() {
  const orders = trpc.account.orders.useQuery();
  return (
    <AccountLayout title="Your orders">
      <div className="account-section account-section--orders">
        {orders.isLoading ? (
          <div
            className="account-list account-list--loading"
            aria-label="Loading orders"
          >
            <div className="skeleton-line" />
            <div className="skeleton-line" />
            <div className="skeleton-line" />
          </div>
        ) : orders.data?.length ? (
          <div className="account-list">
            {orders.data.map(order => (
              <Link
                className="account-list__row"
                href={`/account/orders/${order.publicId}`}
                key={order.id}
              >
                <span>
                  <strong>{order.orderNumber}</strong>
                  <small>
                    {new Date(order.placedAt).toLocaleDateString("en-PK", {
                      dateStyle: "medium",
                    })}
                  </small>
                </span>
                <span className="status-pill">
                  {order.status.replaceAll("_", " ")}
                </span>
                <strong>{pkr(order.totalAmount)}</strong>
                <span className="account-row-arrow" aria-hidden="true">
                  →
                </span>
              </Link>
            ))}
          </div>
        ) : (
          <div className="empty-state account-empty">
            <strong>No orders yet.</strong>
            <span>Your next pair is waiting in the shop.</span>
            <Link className="button-secondary" href="/shop">
              Explore footwear
            </Link>
          </div>
        )}
      </div>
    </AccountLayout>
  );
}

export function OrderDetail() {
  const [, params] = useRoute<{ publicId: string }>(
    "/account/orders/:publicId"
  );
  const orderQuery = trpc.account.order.useQuery(
    { publicId: params?.publicId ?? "" },
    { enabled: Boolean(params?.publicId) }
  );
  const [reviewItemId, setReviewItemId] = useState<number | null>(null);
  const [rating, setRating] = useState(5);
  const [body, setBody] = useState("");
  const [returnOpen, setReturnOpen] = useState(false);
  const [returnReason, setReturnReason] = useState("");
  const [returnSelections, setReturnSelections] = useState<
    Record<number, number>
  >({});
  const returnsQuery = trpc.account.returns.useQuery();
  const requestReturnMutation = trpc.account.requestReturn.useMutation({
    onSuccess: () => {
      toast.success("Return request received.");
      setReturnOpen(false);
      setReturnReason("");
      returnsQuery.refetch();
    },
    onError: error => toast.error(error.message),
  });
  const createReview = trpc.reviews.create.useMutation({
    onSuccess: () => {
      toast.success("Your review is submitted for moderation.");
      setReviewItemId(null);
      setBody("");
    },
    onError: error => toast.error(error.message),
  });
  const selectedReviewItem =
    reviewItemId && orderQuery.data
      ? orderQuery.data.items.find(item => item.id === reviewItemId)
      : undefined;
  const data = orderQuery.data;
  const existingReturn = returnsQuery.data?.find(
    item => item.orderPublicId === data?.order.publicId
  );

  if (orderQuery.isLoading)
    return (
      <AccountLayout title="Order detail">
        <div className="account-section">
          <div
            className="account-list account-list--loading"
            aria-label="Loading order"
          >
            <div className="skeleton-line" />
            <div className="skeleton-line" />
            <div className="skeleton-line" />
          </div>
        </div>
      </AccountLayout>
    );
  if (!data)
    return (
      <AccountLayout title="Order detail">
        <div className="account-section">
          <div className="empty-state">This order is not available.</div>
        </div>
      </AccountLayout>
    );

  const isDelivered = data.order.status === "delivered";
  return (
    <AccountLayout title="Order detail">
      <div className="account-section">
        <div className="order-detail-head">
          <div>
            <span className="eyebrow">{data.order.orderNumber}</span>
            <h2 className="display">
              {data.order.status.replaceAll("_", " ")}
            </h2>
          </div>
          <strong>{pkr(data.order.totalAmount)}</strong>
        </div>
        <div className="summary-card">
          {data.items.map(item => (
            <div className="summary-row" key={item.id}>
              <span>
                {item.productName}
                <small style={{ display: "block" }}>
                  {item.color} · {item.size} × {item.quantity}
                </small>
                {isDelivered && item.productId && (
                  <button
                    className="button-text review-trigger"
                    onClick={() => setReviewItemId(item.id)}
                  >
                    Write a purchase-verified review
                  </button>
                )}
              </span>
              <span>{pkr(item.lineTotal)}</span>
            </div>
          ))}
          <div className="summary-row summary-row--total">
            <span>Payment</span>
            <span>
              {data.order.paymentMethod === "cod"
                ? "Cash on delivery"
                : data.order.paymentStatus}
            </span>
          </div>
        </div>
        {!isDelivered && (
          <p className="review-note">
            Reviews and returns unlock once this order has been marked
            delivered.
          </p>
        )}
        {isDelivered && !existingReturn && !returnOpen && (
          <button
            className="button-text return-trigger"
            onClick={() => {
              setReturnSelections(
                Object.fromEntries(
                  data.items.map(item => [item.id, item.quantity])
                )
              );
              setReturnOpen(true);
            }}
          >
            Request a return
          </button>
        )}
        {existingReturn && (
          <p className="review-note">
            Return request:{" "}
            <strong>{existingReturn.return.status.replaceAll("_", " ")}</strong>
            {existingReturn.return.refundStatus !== "not_requested"
              ? ` · Refund ${existingReturn.return.refundStatus.replaceAll("_", " ")}`
              : " · Refund review begins after approval."}
          </p>
        )}
        {returnOpen && (
          <form
            className="review-form return-form"
            onSubmit={event => {
              event.preventDefault();
              requestReturnMutation.mutate({
                orderPublicId: data.order.publicId,
                reason: returnReason,
                items: Object.entries(returnSelections)
                  .map(([orderItemId, quantity]) => ({
                    orderItemId: Number(orderItemId),
                    quantity,
                  }))
                  .filter(item => item.quantity > 0),
              });
            }}
          >
            <strong>Select the items to return</strong>
            {data.items.map(item => (
              <label
                key={item.id}
                className="payment-option"
                style={{ marginTop: 8 }}
              >
                <input
                  type="checkbox"
                  checked={(returnSelections[item.id] ?? 0) > 0}
                  onChange={event =>
                    setReturnSelections(current => ({
                      ...current,
                      [item.id]: event.target.checked ? item.quantity : 0,
                    }))
                  }
                />
                <span>
                  <strong>{item.productName}</strong>
                  <small style={{ display: "block" }}>
                    {item.color} · {item.size} · max {item.quantity}
                  </small>
                  {(returnSelections[item.id] ?? 0) > 0 && (
                    <input
                      type="number"
                      min={1}
                      max={item.quantity}
                      value={returnSelections[item.id]}
                      onChange={event =>
                        setReturnSelections(current => ({
                          ...current,
                          [item.id]: Math.min(
                            item.quantity,
                            Math.max(1, Number(event.target.value) || 1)
                          ),
                        }))
                      }
                      aria-label={`Quantity of ${item.productName} to return`}
                      style={{ marginTop: 8, maxWidth: 100 }}
                    />
                  )}
                </span>
              </label>
            ))}
            <strong style={{ display: "block", marginTop: 16 }}>
              Why are you returning these items?
            </strong>
            <textarea
              value={returnReason}
              onChange={event => setReturnReason(event.target.value)}
              placeholder="Tell us what happened so our team can help."
              minLength={10}
              maxLength={500}
              required
            />
            <div style={{ display: "flex", gap: 10 }}>
              <button
                className="button-primary"
                type="submit"
                disabled={requestReturnMutation.isPending}
              >
                {requestReturnMutation.isPending
                  ? "Sending…"
                  : "Send return request"}
              </button>
              <button
                className="button-secondary"
                type="button"
                onClick={() => setReturnOpen(false)}
              >
                Cancel
              </button>
            </div>
          </form>
        )}
        {selectedReviewItem?.productId && (
          <form
            className="review-form review-form--active"
            onSubmit={event => {
              event.preventDefault();
              createReview.mutate({
                productId: selectedReviewItem.productId!,
                rating,
                body,
              });
            }}
          >
            <strong>Share your experience</strong>
            <div className="rating-input">
              {[1, 2, 3, 4, 5].map(value => (
                <button
                  type="button"
                  aria-label={`${value} star${value === 1 ? "" : "s"}`}
                  className={
                    value <= rating
                      ? "rating-star rating-star--active"
                      : "rating-star"
                  }
                  onClick={() => setRating(value)}
                  key={value}
                >
                  ★
                </button>
              ))}
            </div>
            <textarea
              value={body}
              onChange={event => setBody(event.target.value)}
              placeholder="Fit, comfort, material and occasion details help other customers."
              minLength={20}
              required
            />
            <div style={{ display: "flex", gap: 10 }}>
              <button
                className="button-primary"
                type="submit"
                disabled={createReview.isPending}
              >
                {createReview.isPending ? "Submitting…" : "Submit review"}
              </button>
              <button
                className="button-secondary"
                type="button"
                onClick={() => setReviewItemId(null)}
              >
                Cancel
              </button>
            </div>
          </form>
        )}
      </div>
    </AccountLayout>
  );
}
